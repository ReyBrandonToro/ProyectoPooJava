package com.funlam.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.beans.factory.annotation.Autowired;

import com.funlam.poo.service.StoreService;


import com.funlam.poo.model.Product;
import com.funlam.poo.model.Store;
import com.funlam.poo.model.User;
import com.funlam.poo.model.Order;
import com.funlam.exception.NotFoundException;

import com.funlam.poo.model.Cart;
import com.funlam.poo.model.CartItem;
import com.funlam.poo.model.UserCartRequest;


import java.util.stream.Collectors;


import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;          
@RestController
@RequestMapping("api/store")
public class StoreController {
    @Autowired
    private StoreService StoreSimulator;
    @PostMapping
    public Store createStore(@RequestBody Store store) {
        StoreSimulator.createStore(store);   
        return StoreSimulator.getStore();
    }
    @PostMapping("/addUser")
    public User createUser(@RequestBody User user) {
        StoreSimulator.addUser(user);
        return user;
    }
    @PostMapping("/addProduct")
    public Product createProduct(@RequestBody Product product) {
        StoreSimulator.addProduct(product);
        return product;
    }
    @PostMapping("/addProductsToCart")
    public void addProductsToCart(@RequestBody UserCartRequest request) {
        StoreSimulator.addProductsToCart(request.getUser().getId(), request.getProducts());           
    }
    @PostMapping("/MakeOrder")
    public void MakeOrder(@RequestBody User user) {
    StoreSimulator.MakeOrder(user);
    }
    @GetMapping("/showUser")
    public List<User> showUser(){
        return StoreSimulator.getUsers();
    }
    @GetMapping("/showProducts")
    public List<Product> showProducts(){
        return StoreSimulator.getProducts();
    }
    @PostMapping("/findProductByID")
    public Product findProductByID(@RequestBody Product product) {
        try {
            return StoreSimulator.findProductByID(product); 
        } catch (NotFoundException e) {
            System.out.println("Error: " + e.getMessage()); 
            StoreSimulator.addProduct(product);
            return product;  
        }
    }
    @PostMapping("/findUserByID")
    public User findUserByID(@RequestBody User user) {
        try {
            return StoreSimulator.findUserByID(user);
        } catch (NotFoundException e) {
            System.out.println("Error: " + e.getMessage());  
            StoreSimulator.addUser(user);
            return user; 
        }
    }
}
