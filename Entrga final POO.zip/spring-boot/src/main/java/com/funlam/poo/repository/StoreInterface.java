package com.funlam.poo.repository;

import java.util.List;

import com.funlam.poo.model.CartItem;
import com.funlam.poo.model.Product;
import com.funlam.poo.model.User;

public interface StoreInterface {
    List<User> getUsers();
    List<Product> getProducts();
    void addUser(User user);
    void addProduct(Product product);
    void addProductsToCart(String useID,List<CartItem> products);
    void MakeOrder(User user);
    Product findProductByID(Product product);
    User findUserByID(User user);
}
