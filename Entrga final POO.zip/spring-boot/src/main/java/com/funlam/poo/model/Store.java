package com.funlam.poo.model;
import java.util.ArrayList;
import java.util.List;

import com.funlam.exception.NotFoundException;

import com.funlam.poo.repository.StoreInterface;
public class Store implements StoreInterface{
    private String name;
    private List<Product> products;  
    private List<User> users; 
    private List<Order> orders; 

    public Store() {  // Added constructor for Store
        this.name = "default";
        this.products = new ArrayList<>();
        this.users = new ArrayList<>();
        this.orders = new ArrayList<>();
    }

    public Store(String name) {  // Added constructor for Store
        this.name = name;
        this.products = new ArrayList<>();
        this.users = new ArrayList<>();
        this.orders = new ArrayList<>();
    }


    public void addProduct(Product product) {
        products.add(product);
    }

    public List<Product> getProducts() {
        return products;
    }

    public void addUser(User user) {
        users.add(user);
    }

    public List<User> getUsers() {
        return users;
    }

    public User findUserByID(User user) {
        for (User userl : users) {
            if (userl.getId().equalsIgnoreCase(user.getId())) {
                return userl;
            }
        }
        throw new NotFoundException("Product with ID '" + user.getId() + "' not found");
    }

    
    public void MakeOrder(Order order) {
        orders.add(order); 
    }

    public List<Order> getOrders() {
        return orders;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Product findProductByID(Product product){
        for (Product productl :products) {
            if (productl.getId().equalsIgnoreCase(product.getId())) {
                return productl;
            }
        }
        throw new NotFoundException("Product with ID '" + product.getId() + "' not found");
    }

    public void UserAddProductCart(String useID,Product product,int quantity){       
        for (User user : users) {
            if (user.getId().equalsIgnoreCase(useID)) {
                user.addProductToCart(product,quantity);      
            }
        }
    }

    public void addProductsToCart(String userID,List<CartItem> products){       
        for (User user : users) {
            if (user.getId().equalsIgnoreCase(userID)) {
                for(CartItem product: products){
                    user.addProductToCart(product.getProduct(),product.getQuantity());                    
                }  
                user.getCart().calculateSubTotal(); 
            }
        }
    }

    public void MakeOrder(User user){
        for(User userl :users){
            if(userl.getId().equalsIgnoreCase(user.getId())){
                userl.createOrder();
                userl.emptyCart();
            }
        }

    }

}

