package com.funlam.poo.model;
import java.util.ArrayList;
import java.util.List;
import com.funlam.poo.repository.Identifiable;;
public class Order implements Identifiable {
    private String id;
    private List<CartItem> products;
    private double total;

    public Order(Cart cart) {  // Composition: Order is created based on a Cart
        this.products = new ArrayList<>(cart.getProducts());
        this.total = 0;
        cart.emptyCart();
    }

    public String getId(){
        return id;
    }

    public void setId(String id){
        this.id=id;
    }

    public void calculateTotal() {
        double totalTemp = 0;
        for (CartItem item : products) {
            totalTemp += item.getProduct().getPrice() * item.getQuantity();
        }
        this.total = totalTemp;
    }

    public double getTotal() {
        return total;
    }

    public List<CartItem> getProducts() {
        return products;
    }
}

