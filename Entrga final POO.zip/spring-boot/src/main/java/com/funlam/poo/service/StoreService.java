package com.funlam.poo.service;

import org.springframework.stereotype.Service;

import com.funlam.poo.model.Store;
import com.funlam.poo.model.Product;
import com.funlam.poo.model.User;
import com.funlam.poo.model.Order;
import com.funlam.exception.NotFoundException;
import com.funlam.poo.model.Cart;
import com.funlam.poo.model.CartItem;
import java.util.List;

import com.funlam.poo.repository.StoreInterface;
@Service
public class StoreService implements StoreInterface{
    private Store store;
    private User user;
    private Product product;



    public StoreService(){
    }

    public Store getStore(){
        return store;
    }

    public List<User> getUsers(){
       return store.getUsers();
    }

    public List<Product> getProducts(){
       return store.getProducts();
    }

    public void createStore(Store store){
        this.store=store;
    }

    public void addUser(User user){
        store.addUser(user);
    }

    public void addProduct(Product product){
        store.addProduct(product);
    }

    public void addProductsToCart(String useID,List<CartItem> products){
        store.addProductsToCart(useID,products);
    }

    public void MakeOrder(User user){
        store.MakeOrder(user);
    }

    public Product findProductByID(Product product){
        return store.findProductByID(product);
    }

    public User findUserByID(User user){
        return store.findUserByID(user);
    }
}
