package com.funlam.poo.model;
import com.funlam.poo.repository.Identifiable;
public class Product implements Identifiable {
    private String id;
    private String name;
    private double price;

    public Product() {
    }

    public void setId(String id){
        this.id=id;
    }

    public String  getId(){
        return id;
    }

    public Product(String name, double price) {  
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
}

