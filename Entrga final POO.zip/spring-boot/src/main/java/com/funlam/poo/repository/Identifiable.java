package com.funlam.poo.repository;

public interface Identifiable {
    String getId(); 
    void setId(String id); 
}
