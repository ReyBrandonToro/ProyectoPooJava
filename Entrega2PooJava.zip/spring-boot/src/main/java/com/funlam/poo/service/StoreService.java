package com.funlam.poo.service;

import org.springframework.stereotype.Service;

import com.funlam.poo.model.Store;
import com.funlam.poo.model.Product;
import com.funlam.poo.model.User;
import com.funlam.poo.model.Order;
import com.funlam.poo.model.Cart;
import com.funlam.poo.model.CartItem;

import java.util.List;

@Service
public class StoreService {
    private Store store;
    private User user;
    private Product product;

    public StoreService(){
    }

    public Store getStore(){
        return store;
    }

    public List<User> getUsers(){
       return store.getUsers();
    }

    public List<Product> getProducts(){
       return store.getProducts();
    }

    public void createStore(Store store){
        this.store=store;
    }

    public void createUser(User user){
        store.addUser(user);
    }

    public void createProduct(Product product){
        store.addProduct(product);
    }

    public void addProductsToCart(String userName,List<CartItem> products){
        store.UserAddProductsCart(userName,products);
    }

    public void MakeOrder(User user){
        store.MakeOrder(user.getName());
    }
}
