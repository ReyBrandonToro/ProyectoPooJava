package com.funlam.poo.model;
import java.util.ArrayList;
import java.util.List;

import java.util.Map;

public class Store {
    private String name;
    private List<Product> products;  
    private List<User> users; 
    private List<Order> orders; 

    public Store() {  // Added constructor for Store
        this.name = "default";
        this.products = new ArrayList<>();
        this.users = new ArrayList<>();
        this.orders = new ArrayList<>();
    }

    public Store(String name) {  // Added constructor for Store
        this.name = name;
        this.products = new ArrayList<>();
        this.users = new ArrayList<>();
        this.orders = new ArrayList<>();
    }


    public void addProduct(Product product) {
        products.add(product);
    }

    public List<Product> getProducts() {
        return products;
    }

    public void addUser(User user) {
        users.add(user);
    }

    public List<User> getUsers() {
        return users;
    }

    public User findUser(String name) {
        for (User user : users) {
            if (user.getName().equalsIgnoreCase(name)) {
                return user;
            }
        }
        return null;
    }

    

    public void addOrder(Order order) {
        orders.add(order); 
    }

    public List<Order> getOrders() {
        return orders;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Product findProductByName(String productName){
        for (Product product :products) {
            if (product.getName().equalsIgnoreCase(productName)) {
                return product;
            }
        }
        return null;
    }

    public void UserAddProductCart(String userName,Product product,int quantity){       
        for (User user : users) {
            if (user.getName().equalsIgnoreCase(userName)) {
                user.addProductToCart(product,quantity);      
            }
        }
    }

    public void UserAddProductsCart(String userName,List<CartItem> products){       
        for (User user : users) {
            if (user.getName().equalsIgnoreCase(userName)) {
                for(CartItem product: products){
                    user.addProductToCart(product.getProduct(),product.getQuantity());                    
                }  
                user.getCart().calculateSubTotal(); 
            }
        }
    }

    public void MakeOrder(String userName){
        for(User user :users){
            if(user.getName().equalsIgnoreCase(userName)){
                user.createOrder();
                user.emptyCart();
            }
        }

    }

}

