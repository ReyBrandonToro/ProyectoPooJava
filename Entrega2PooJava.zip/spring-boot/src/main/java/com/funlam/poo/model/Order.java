package com.funlam.poo.model;
import java.util.ArrayList;
import java.util.List;

public class Order {
    private int idOrder;
    private List<CartItem> products;
    private double total;

    public Order(Cart cart) {  // Composition: Order is created based on a Cart
        this.products = new ArrayList<>(cart.getProducts());
        this.total = 0;
        cart.emptyCart();
    }



    public void calculateTotal() {
        double totalTemp = 0;
        for (CartItem item : products) {
            totalTemp += item.getProduct().getPrice() * item.getQuantity();
        }
        this.total = totalTemp;
    }

    public double getTotal() {
        return total;
    }

    public List<CartItem> getProducts() {
        return products;
    }

    public void setIdOrder(int idOrder){
        this.idOrder=idOrder;
    }

    public int getIdOrder(){
        return idOrder;
    }
}

