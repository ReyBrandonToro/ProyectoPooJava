package com.funlam.poo.model;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    double total;
    private List<CartItem> products;

    public Cart() {
        this.products = new ArrayList<>();
        total = 0;
    }

    public void addProduct(Product product, int quantity) {
        for (CartItem item : products) {
            if (item.getProductName().equalsIgnoreCase(product.getName())) {
                item.setQuantity(item.getQuantity() + quantity);
                return;
            }
        }
        products.add(new CartItem(product, quantity));
    }

    public void removeProduct(Product product) {
        products.removeIf(item -> item.getProduct().equals(product));
    }

    public void calculateSubTotal() {
        for (CartItem item : products) {
            total += item.getProduct().getPrice() * item.getQuantity();
        }
    }

    public double getTotal(){
        return total;
    }

    public void emptyCart() {
        products.clear();
        total=0.0;

    }

    public List<CartItem> getProducts() {
        return products;
    }
}

