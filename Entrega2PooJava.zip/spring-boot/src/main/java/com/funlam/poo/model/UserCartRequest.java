package com.funlam.poo.model;
import java.util.ArrayList;
import java.util.List;

public class UserCartRequest {
    private User user;
    private List<CartItem> products;
    
    // Constructor
    public UserCartRequest() {}
    
    public UserCartRequest(User user, List<CartItem> products) {
        this.user = user;
        this.products = products;
    }
    
    // Getters and Setters
    public User getUser() {
        return user;
    }
    
    public void setUser(User user) {
        this.user = user;
    }

    public List<CartItem> getProducts() {
        return products;
    }
    
    public void setProducts(List<CartItem> products) {
        this.products = products;
    }

}
