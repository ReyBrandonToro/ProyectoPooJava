package com.funlam.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.beans.factory.annotation.Autowired;

import com.funlam.poo.service.StoreService;


import com.funlam.poo.model.Product;
import com.funlam.poo.model.Store;
import com.funlam.poo.model.User;
import com.funlam.poo.model.Order;
import com.funlam.poo.model.Cart;
import com.funlam.poo.model.CartItem;
import com.funlam.poo.model.UserCartRequest;


import java.util.stream.Collectors;


import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;          
import java.util.ArrayList;
import java.util.Map;
@RestController
@RequestMapping("api/store")
public class StoreController {
    @Autowired
    private StoreService StoreSimulator=new StoreService();
    @PostMapping
    public Store createStore(@RequestBody Store store) {
        StoreSimulator.createStore(store);
    return StoreSimulator.getStore();
    }
    @PostMapping("/createUser")
    public User createUser(@RequestBody User user) {
        StoreSimulator.createUser(user);
        return user;
    }
    @PostMapping("/createProduct")
    public Product createProduct(@RequestBody Product product) {
        StoreSimulator.createProduct(product);
        return product;
    }
    @PostMapping("/addProductsToCart")
    public void addProductsToCart(@RequestBody UserCartRequest request) {
        StoreSimulator.addProductsToCart(request.getUser().getName(), request.getProducts());           
    }
    @PostMapping("/MakeOrder")
    public void MakeOrder(@RequestBody User user) {
    StoreSimulator.MakeOrder(user);
    }
    @GetMapping("/showUser")
    public List<User> showUser(){
        return StoreSimulator.getUsers();
    }
    @GetMapping("/showProducts")
    public List<Product> showProducts(){
        return StoreSimulator.getProducts();
    }
    

}
