package com.funlam.poo.model;
import java.util.ArrayList;
import java.util.List;

public class User {
    private String name;
    private String email;
    private Cart cart;  
    private List<Order> orders;  

    public User() {
        this.cart = new Cart();
        this.orders = new ArrayList<>();
    }   

    public User(String name, String email) {  
        this.name = name;
        this.email = email;
        this.cart = new Cart();  
        this.orders = new ArrayList<>();  
    }

    public Cart getCart() {
        return cart;
    }

    public void addProductToCart(Product product,int quantity){
        cart.addProduct(product, quantity);
    }
    
    public void addProductsToCart(){

    }

    public void addOrder(Order order) {
        orders.add(order);
    }

    public List<Order> getOrders() {
        return orders;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void createOrder() {
        Order newOrder = new Order(cart);
        newOrder.calculateTotal();
        orders.add(newOrder);

    }
    
    public void emptyCart() {
        cart.emptyCart();
    }
}

