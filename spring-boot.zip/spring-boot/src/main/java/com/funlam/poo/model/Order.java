package com.funlam.poo.model;
import java.util.ArrayList;
import java.util.List;

public class Order {
    private List<CartItem> products;
    private double total;

    public Order(Cart cart) {  // Composition: Order is created based on a Cart
        this.products = new ArrayList<>(cart.getProducts());
        this.total = 0;
        cart.emptyCart();
    }



    public void calculateTotal() {
        /*double totalTemp = 0;
        for (Map.Entry<Product, Integer> entry : products.entrySet()) {
            totalTemp += entry.getKey().getPrice() * entry.getValue();
        }
        this.total = totalTemp;*/
    }

    public double getTotal() {
        return total;
    }

    public List<CartItem> getProducts() {
        return products;
    }
}

