package com.funlam.poo.model;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    private List<CartItem> products;

    public Cart() {
        this.products = new ArrayList<>();
    }

    public void addProduct(Product product, int quantity) {
        for (CartItem item : products) {
            if (item.getProductName().equalsIgnoreCase(product.getName())) {
                item.setQuantity(item.getQuantity() + quantity);
                return;
            }
        }
        products.add(new CartItem(product, quantity));
    }

    public void removeProduct(Product product) {
        products.removeIf(item -> item.getProduct().equals(product));
    }

    public double calculateSubTotal() {
        double total = 0;
        for (CartItem item : products) {
            total += item.getProduct().getPrice() * item.getQuantity();
        }
        return total;
    }

    public void emptyCart() {
        products.clear();
    }

    public List<CartItem> getProducts() {
        return products;
    }
}

